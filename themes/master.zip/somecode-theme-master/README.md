# Somecode theme for Pico
A stupidly simple & blazing fast theme for an stupidly simple & blazing fast, flat file CMS.
![Preview of theme](preview.png)
